from django.apps import AppConfig


class WellTrackerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "well_tracker"
